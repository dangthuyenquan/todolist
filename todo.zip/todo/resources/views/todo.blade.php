<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<style>
		#todo-list li{
			margin: 10px 0;
		}
		#todo-list .active{
			background: #dedede;
		}
	</style>
</head>
<body>
	<h1>TODO</h1>
	<form id="todo-form" class="ng-pristine ng-valid">
		<input id="new-todo" placeholder="What needs to be done?" autofocus="" class=""><br><br>
		<textarea id="description" hidden rows="4"></textarea><br>
		<input type="submit" value="Create">
	</form>
	<hr>
	<h2>Todo list</h2>
	<ul id="todo-list">
		<?php 
			$data = [];

			if(File::exists('data.json')){
			 	$data = json_decode(File::get('data.json'),true);
			}

		 ?>

		 @if($data)
			@foreach( $data as $todo )
				
			<li>
				<div class="view">
					<span class="name">{!!$todo['name']!!}</span> - <span class="date">{!!$todo['date']!!}</span> <button>X</button>
				</div>
				
				<ul>

				@if( isset($todo['children']) )
					@foreach($todo['children'] as $todo_children)
						<li>
						<div class="view">
							<span class="name">{!!$todo_children['name']!!}</span> - <span class="date">{!!$todo_children['date']!!}</span> - <span class="description">{!!$todo_children['description']!!}</span> <button>X</button>
						</div>
						</li>
					@endforeach
				@endif
				
				</ul>

			</li>

			@endforeach
		 @endif

	</ul>
		
	<hr>
	<button id="save">Save</button>
	<script
  src="https://code.jquery.com/jquery-2.2.4.min.js"
  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
  crossorigin="anonymous"></script>
  <script>
  	$("#todo-form").submit(function(event) {
  		event.preventDefault() ;

  		if( $('#todo-list .active').length > 0 ){

			if( $('#todo-list .active ul').length < 1){
				$('#todo-list .active').eq(0).append('<ul><li>'
								+'<div class="view">'
									+'<span class="name">'+$('#new-todo').val()+'</span>'+' - <span class="date">'+new Date().toISOString().slice(0,10)+'</span> - <span class="description">'+$('#description').val()+'</span> <button>X</button>'
								+'</div>'
							+'</li></ul>');
				
			}else{
				$('#todo-list .active ul').eq(0).append('<li>'
								+'<div class="view">'
									+'<span class="name">'+$('#new-todo').val()+'</span>'+' - <span class="date">'+new Date().toISOString().slice(0,10)+'</span> - <span class="description">'+$('#description').val()+'</span> <button>X</button>'
								+'</div>'
							+'</li>');
			}

			$('#description').val('');
			
		}else{
			$('#todo-list').append('<li>'
								+'<div class="view">'
									+'<span class="name">'+$('#new-todo').val()+'</span>'+' - <span class="date">'+new Date().toISOString().slice(0,10)+'</span> <button>X</button>'
								+'</div>'
							+'</li>');
		}
		$("#new-todo").val('');
  		
  		
  	});
  	$('#todo-list').on('click', 'li', function(event) {
  		if( $(this).hasClass('active') ){
  			$('#todo-list .active').removeClass('active');
  		}else{
  			$('#todo-list .active').removeClass('active');
  			$(this).addClass('active');
  		}

  		check_add_todo_item();
  	});

  	function check_add_todo_item(){

  		if($('#todo-list .active').length > 0){
  			$('#description').show();
  		}else{
  			$('#description').hide();
  		}

  	}

  	$('#todo-list').on('click', 'li button', function(event) {
  		event.stopPropagation();
  		$(this).closest('li').remove();	
  		check_add_todo_item();
  	});


  	$('#save').click(function(event) {
  		var data = [],children = [];

  		$('#todo-list>li').each(function(index, el) {
  				
  			if($(el).find('ul li').length > 0){

  				children = [];
  				$(el).find('ul li').each(function(index, el) {
  					children.push({'name':$(el).find('.name').eq(0).text(),'description':$(el).find('.description').eq(0).text(),'date':$(el).find('.date').eq(0).text()})
  				});

  				data.push({'name':$(el).find('.name').eq(0).text(),'date':$(el).find('.date').eq(0).text(),'children':children});

  			}else{

  				data.push({'name':$(el).find('.name').eq(0).text(),'date':$(el).find('.date').eq(0).text()});

  			}

  		});

  		$.ajax({
  			url: '{!!route('post-todo')!!}',
  			type: 'POST',
  			dataType: 'Json',
  			data: {
  				_token:'{!!csrf_token()!!}',
  				data: data,
  			},
  			success:function(data){
  				if(data.result){
  					window.location.reload();
  				}else{
  					alert('error');
  				}
  			}
  		})
  		.done(function() {
  			console.log("success");
  		})
  		.fail(function() {
  			console.log("error");
  		})
  		.always(function() {
  			console.log("complete");
  		});

  	});
  </script>
</body>
</html>